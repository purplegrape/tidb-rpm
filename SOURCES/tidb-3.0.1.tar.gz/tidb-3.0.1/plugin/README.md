# The Plugin Framework

https://github.com/pingcap/tidb/blob/master/docs/design/2018-12-10-plugin-framework.md
