// Copyright 2016 TiKV Project Authors. Licensed under Apache-2.0.

#![feature(test)]

extern crate test;

mod bench_channel;
