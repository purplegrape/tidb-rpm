## cmd

This directory is meant to enforce vendoring for pd binaries without polluting
the pd client libraries with vendored dependencies.
