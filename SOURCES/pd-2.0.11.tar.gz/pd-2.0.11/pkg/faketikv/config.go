package faketikv

// Config is the faketikv configuration.
type Config struct {
}
