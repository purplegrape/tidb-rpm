---
name: "\U0001F41B Bug Report"
about: Something isn't working as expected

---

## Bug Report

**What version of Rust are you using?**
<!-- You can run `rustc --version` -->

**What operating system and CPU are you using?**
<!-- You can run `cat /proc/cpuinfo` -->

**What did you do?**
<!-- If possible, provide a recipe for reproducing the error. A complete runnable program is good. -->

**What did you expect to see?**

**What did you see instead?**
