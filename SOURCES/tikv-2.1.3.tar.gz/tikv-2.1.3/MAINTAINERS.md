# Maintainers

This file lists who are the core maintainers of the TiKV project. 

# Project Lead

* [Siddon Tang](https://github.com/siddontang); tl@pingcap.com

# Other Core Maintainers

* [Jay Li](https://github.com/busyjay); jay@pingcap.com; Focus Areas: Raft, Coprocessor
* [Jinpeng Zhang](https://github.com/zhangjinpeng1987); zhangjinpeng@pingcap.com; Focus Areas: Storage, Transaction
