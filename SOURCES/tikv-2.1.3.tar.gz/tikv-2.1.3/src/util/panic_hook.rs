// Copyright 2016 PingCAP, Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// See the License for the specific language governing permissions and
// limitations under the License.

use std::cell::RefCell;
use std::panic::{self, PanicInfo};
use std::sync::{Mutex, Once, ONCE_INIT};
use std::{process, thread};

use super::{create_panic_mark_file, panic_mark_is_on};
use backtrace::Backtrace;
use log::LogLevel;
use slog_scope::GlobalLoggerGuard;

/// A simple panic hook that allows skiping printing stacktrace conditionaly.

static INIT: Once = ONCE_INIT;
// store the default panic hook defined in std.
static mut DEFAULT_HOOK: Option<*mut (Fn(&PanicInfo) + 'static + Sync + Send)> = None;

thread_local! {
    static MUTED: RefCell<bool> = RefCell::new(false)
}

/// Replace the default hook if we haven't.
fn initialize() {
    unsafe {
        DEFAULT_HOOK = Some(Box::into_raw(panic::take_hook()));
        panic::set_hook(box track_hook);
    }
}

/// Skip printing the stacktrace if panic.
pub fn mute() {
    INIT.call_once(initialize);
    MUTED.with(|m| *m.borrow_mut() = true);
}

/// Print the stacktrace if panic.
pub fn unmute() {
    MUTED.with(|m| *m.borrow_mut() = false);
}

/// Print the stacktrace according to the static MUTED.
fn track_hook(p: &PanicInfo) {
    MUTED.with(|m| {
        if *m.borrow() {
            return;
        }
        unsafe {
            if let Some(hook) = DEFAULT_HOOK {
                (*hook)(p);
            }
        }
    });
}

/// Exit the whole process when panic.
pub fn set_exit_hook(panic_abort: bool, guard: Option<GlobalLoggerGuard>, data_dir: &str) {
    // HACK! New a backtrace ahead for caching necessary elf sections of this
    // tikv-server, in case it can not open more files during panicking
    // which leads to no stack info (0x5648bdfe4ff2 - <no info>).
    //
    // Crate backtrace caches debug info in a static variable `STATE`,
    // and the `STATE` lives forever once it has been created.
    // See more: https://github.com/alexcrichton/backtrace-rs/blob/\
    //           597ad44b131132f17ed76bf94ac489274dd16c7f/\
    //           src/symbolize/libbacktrace.rs#L126-L159
    // Caching is slow, spawn it in another thread to speed up.
    thread::Builder::new()
        .name(thd_name!("backtrace-loader"))
        .spawn(Backtrace::new)
        .unwrap();

    // Hold the guard.
    let log_guard = Mutex::new(guard);

    let orig_hook = panic::take_hook();
    let data_dir = data_dir.to_string();
    panic::set_hook(box move |info: &PanicInfo| {
        if log_enabled!(LogLevel::Error) {
            let msg = match info.payload().downcast_ref::<&'static str>() {
                Some(s) => *s,
                None => match info.payload().downcast_ref::<String>() {
                    Some(s) => &s[..],
                    None => "Box<Any>",
                },
            };
            let thread = thread::current();
            let name = thread.name().unwrap_or("<unnamed>");
            let loc = info
                .location()
                .map(|l| format!("{}:{}", l.file(), l.line()));
            let bt = Backtrace::new();
            error!(
                "thread '{}' panicked '{}' at {:?}\n{:?}",
                name,
                msg,
                loc.unwrap_or_else(|| "<unknown>".to_owned()),
                bt
            );
        } else {
            orig_hook(info);
        }

        // To collect remaining logs, drop the guard before exit.
        drop(log_guard.lock().unwrap().take());

        // If PANIC_MARK is true, create panic mark file.
        if panic_mark_is_on() {
            create_panic_mark_file(data_dir.clone());
        }

        if panic_abort {
            process::abort();
        } else {
            process::exit(1);
        }
    })
}
