// Copyright 2018 TiKV Project Authors. Licensed under Apache-2.0.

//! Make cargo happy.
//! Fuzzer binaries will be generated dynamically via `fuzz/cli.rs`.
