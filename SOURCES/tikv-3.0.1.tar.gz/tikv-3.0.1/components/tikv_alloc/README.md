#Usage

```
$ cargo build  --no-default-features --features="tcmalloc"
```

Or:

```rust
$ TCMALLOC=1 make build
```